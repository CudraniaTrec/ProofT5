# TyFlow Results Package

Result records backing the tables of "TyFlow: A Type-Aware Approach to
Neural Code Models". Each folder corresponds to one table or analysis.
Metric conventions follow Sec. 6.1 of the paper: pass@k as a fraction of
tasks, CER as a fraction of candidates, FSP as the mean rank of the first
correct candidate.

## Layout

- `rq1_table1/` — Table 1 (pass@1 / pass@10 / FSP / CER per model row).
  One JSON per row; the filename gives scale, benchmark, and model. Each
  JSON records `problems`, `pass1`, `pass10`,
  `average_first_success_position`, and `compile_error_rate`, with
  per-task arrays where applicable.
- `table3_decoder_only/` — Table 3 (pass@1 of the prompted decoder-only
  models). Filenames: `<model>_<zero|few>_<benchmark>.json`; the zero
  condition uses the task prompt only, the few condition prepends three
  solved examples for the Java benchmarks and six for SuFu.
- `rq2_runtime/` — Table 4 (per-step and per-task runtime). One JSONL per
  configuration: `sufunocheck` (base), `sufugrammar` (+syntactic pruning),
  `sufucoq` (+type pruning), `sufucoqview` (+dynamic typing context).
- `rq2_pruning_stats/` — the instrumented-decoder statistics of Sec. 6.2.2
  (syntactic, type, and final-check rejection rates).
- `rq3_table5/` — Table 5 (RQ3): pass@1 / pass@10 and compilation
  statistics of the ordinary control and the four external methods
  (rejection sampling, SynCode, Repilot, iterative repair).
- `appendix_d/` — Appendix D: the SuFu 2B paired-difference statistics
  (sign-flip test with cluster-bootstrap CIs).
