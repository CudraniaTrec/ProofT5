#!/usr/bin/env bash
# Self-test for the packaged SuFu benchmark environment.
#
# 1. Runs the bundled OCaml bytecode executor on a tiny program.
# 2. Materializes the gold solutions of the requested split as candidate
#    files and scores them with eval/score.py.  A healthy environment must
#    reproduce pass@1 = 100% on gold solutions.
set -euo pipefail

SPLIT="${1:-test}"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "== [1/3] executor smoke test =="
SMOKE="$(mktemp --suffix=.f)"
cat > "$SMOKE" <<'EOF'
Inductive List = cons {Int, List} | nil Unit;
main = \xs: List. match xs with nil _ -> 0 | cons {h, t} -> h end;
main (cons {42, (nil unit)});
EOF
"$HERE/executor/ocamlrun" "$HERE/executor/surface/f" "$SMOKE"
rm -f "$SMOKE"

echo
echo "== [2/3] materialize gold solutions ($SPLIT split) =="
GOLD_DIR="$(mktemp -d)"
python3 - "$HERE" "$GOLD_DIR" "$SPLIT" <<'EOF'
import os
import pickle
import sys

pkg_root, out_dir, split = sys.argv[1], sys.argv[2], sys.argv[3]
data = pickle.load(open(os.path.join(pkg_root, "problems", "splits", f"sufu_{split}.pkl"), "rb"))
for idx, row in enumerate(data):
    with open(os.path.join(out_dir, f"{idx}_0.txt"), "w") as f:
        f.write(row["code"])
print(f"wrote {len(data)} gold candidate files to {out_dir}")
EOF

echo
echo "== [3/3] score gold solutions =="
python3 "$HERE/eval/score.py" \
    --split "$SPLIT" \
    --candidates_dir "$GOLD_DIR" \
    --pass_at_k 1 \
    --json_out "$GOLD_DIR/summary.json"

STATUS=0
python3 - "$GOLD_DIR/summary.json" <<'EOF' || STATUS=1
import json
import sys

summary = json.load(open(sys.argv[1]))
if summary["pass1"] == 1.0:
    print("SELFTEST OK: gold solutions score pass@1 = 100%")
else:
    print(
        f"SELFTEST FAILED: gold pass@1 = {summary['pass1']:.2%}, "
        f"unsolved ids = {[i for i in summary['problem_ids'] if i not in summary['solved']]}"
    )
    sys.exit(1)
EOF
rm -rf "$GOLD_DIR"
exit $STATUS
