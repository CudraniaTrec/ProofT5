# SuFu Benchmark Package (2026-09-06)

Self-contained packaging of the ProofT5 project's SuFu benchmark: the 290
problem corpus, the canonical train/test splits, the OCaml surface-language
executor used for scoring, and a standalone pass@k scorer.  No dependencies
beyond Python 3 (standard library only) and Linux x86_64.

Verified on this machine: gold solutions score pass@1 = 100% on both splits
(58/58 test, 232/232 train) using only the files in this package.

## Contents

```text
sufu_benchmark_package_20260906/
├── README.md                 # this file
├── run_selftest.sh           # env check + gold-solution scoring (see below)
├── problems/
│   ├── sufu.json             # 290 problems: desc, code, lib_code, task_code, tests
│   ├── info.json             # type-definition inventory + prompts used at gen time
│   ├── new_tokens.json       # extra DSL tokens added to model vocabularies
│   ├── tokenizer.pkl         # DSL tokenizer used by the training pipeline
│   └── splits/
│       ├── sufu_train.pkl    # 232 problems (rows: file_name, nl, prefix, postfix,
│       └── sufu_test.pkl     #  58 problems   code, tests, output)
├── benchmark/                # original SuFu .f corpus (291 files; autolifter-base.f
│                             #   is excluded from the 290-problem dataset)
├── label/                    # 317 per-problem synthesis labels (upstream format)
├── executor/
│   ├── ocamlrun              # OCaml 4.14.1 bytecode runtime (x86_64, needs libc/libm only)
│   └── surface/              # compiled surface-language parser/interpreter `f` + sources
├── eval/
│   └── score.py              # standalone scorer (adapted from score_sufu_no_write.py)
└── decoding/                 # optional, for constrained-decoding experiments
    ├── sufu_model.py         # Python parser / type-check / printer helpers
    └── tree-sitter-sufu/     # tree-sitter grammar for SuFu syntax
```

## Problem corpus (290 problems)

| Suite | Category | Count |
|---|---|---|
| autolifter | dac | 36 |
| autolifter | lsp | 8 |
| autolifter | segment-tree | 13 |
| autolifter | single-pass | 39 |
| fusion | algprog | 5 |
| fusion | deforestation | 2 |
| fusion | identities | 3 |
| fusion | shortcut | 4 |
| fusion | tupling | 2 |
| synduce | constraints | 94 |
| synduce | list | 28 |
| synduce | tree | 13 |
| synduce | treepaths | 6 |
| synduce | ptree | 5 |
| synduce | combine | 3 |
| synduce | indexed_list | 3 |
| synduce | sorted_list | 3 |
| synduce | tailopt | 3 |
| synduce | list_to_tree | 4 |
| synduce | misc | 4 |
| synduce | compressed_list | 1 |
| synduce | expressions | 2 |
| synduce | nested_list | 2 |
| synduce | numbers | 2 |
| synduce | terms | 1 |
| synduce | unimodal_lists | 2 |
| synduce | zipper | 2 |
| **Total** | | **290** |

Splits: train 232 / test 58 (no overlap; ids in the pkl `file_name` fields).
Each problem provides a natural-language `desc`/`nl`, the library context
(`lib_code`/`prefix`), the task program (`task_code`), test statements, and
the expected interpreter output for the gold solution.

## Evaluation environment

- Executor: `executor/surface/f`, OCaml 4.14.1 bytecode from the local
  (lightly modified) SuFu source tree; invoked as
  `executor/ocamlrun executor/surface/f program.f`.  It parses, type-checks
  and interprets a SuFu surface-language program, printing declarations and
  test results to stdout.  The bundled `ocamlrun` is self-contained
  (verified with `env -i`; libc/libm only).
- Scoring: candidate program + test statements are written to a temp
  `test.f`, executed with a per-candidate timeout (default 1 s), and stdout
  is compared against the recorded expected output.  Candidates that fail to
  parse count as compile errors; runtime/timeout failures are retries on the
  program without tests.  Metrics: pass@1, pass@k, compile-error rate.
- Two comparison modes (both used in the project):
  - default `full_stdout`: exact stdout equality;
  - `--compare_test_results_only`: compare only the trailing per-test
    result lines, ignoring declaration names.

## Usage

Self-test (executor smoke test + gold solutions must score 100%):

```bash
./run_selftest.sh test    # or: train
```

Score model outputs.  Write each candidate as `{idx}_{cand}.{txt|java}`
(= problem index in the split pkl, candidate index, e.g. `0_0.txt`), then:

```bash
python3 eval/score.py \
    --split test \
    --candidates_dir /path/to/candidates \
    --pass_at_k 10 \
    --json_out result.json
```

Useful flags: `--compare_test_results_only`, `--timeout`, `--workers`,
`--indices 0,3,5`, `--limit 10`.

## Notes and provenance

- Upstream project: SuFu (PLDI'24 "Superfusion"), source at
  `SuFu/SuFu_origin` in the ProofT5 repo; the scoring executor comes from
  the modified tree `SuFu/SuFu` (surface-language parser only).
- `problems/splits/*.pkl` are byte-identical copies of
  `Utils/data/sufucoq/{train,test}.pkl` in the ProofT5 repo (task `sufucoq`).
- The scorer mirrors `score_sufu_no_write.py` with package-relative paths;
  behavior (PTree merge fix, error-solution filters, timeout retry) is
  unchanged.
- Model checkpoints, beam-search decoders, and the full C++ SuFu synthesizer
  are intentionally not included; they live in the ProofT5 repo / user-local
  build directories.
